package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.SoundPool
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.sin

enum class AudioMode {
    COLLISION_MODE,
    PLAYLIST_MODE,
    LOOP_MODE,
    RANDOM_MODE
}

enum class SoundPreset {
    PENTATONIC_SYNTH,
    MARIMBA_CHIME,
    BEATBOX_DRUMS,
    PIANO_MELODY,
    COSMIC_LEAD
}

data class AudioConfig(
    val audioMode: AudioMode = AudioMode.COLLISION_MODE,
    val preset: SoundPreset = SoundPreset.PENTATONIC_SYNTH,
    val volume: Float = 0.8f,
    val pitch: Float = 1.0f,
    val playbackSpeed: Float = 1.0f,
    val collisionCooldownMs: Long = 60L, // Cooldown to prevent overlapping/harsh noise
    val isMuted: Boolean = false,
    val customAudioPath: String? = null
)

class AudioEngine(private val context: Context) {

    var config: AudioConfig = AudioConfig()
    private var lastTriggerTimeMs: Long = 0L
    private var currentBeatIndex: Int = 0

    // SoundPool for instant sample playback
    private var soundPool: SoundPool? = null
    private val freqSoundMap = java.util.concurrent.ConcurrentHashMap<Float, Int>()

    // Frequency notes for synthesized pentatonic scale
    private val pentatonicScale = floatArrayOf(
        261.63f, // C4
        293.66f, // D4
        329.63f, // E4
        392.00f, // G4
        440.00f, // A4
        523.25f, // C5
        587.33f, // D5
        659.25f, // E5
        783.99f, // G5
        880.00f  // A5
    )

    init {
        initSoundPool()
        preGenerateSynthAudio()
    }

    private fun initSoundPool() {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        soundPool = SoundPool.Builder()
            .setMaxStreams(12)
            .setAudioAttributes(attrs)
            .build()
    }

    private fun preGenerateSynthAudio() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val cacheDir = context.cacheDir
                for (freq in pentatonicScale) {
                    val pcm = generatePcmSineWave(freq, 0.15f)
                    val wavHeader = generateWavHeader(pcm.size, 22050)
                    val wavFile = java.io.File(cacheDir, "note_${freq.toInt()}.wav")
                    java.io.FileOutputStream(wavFile).use { fos ->
                        fos.write(wavHeader)
                        fos.write(pcm)
                    }
                    soundPool?.load(wavFile.absolutePath, 1)?.let { soundId ->
                        freqSoundMap[freq] = soundId
                    }
                }
            } catch (e: Exception) {
                Log.e("AudioEngine", "Error initializing synth sound pool", e)
            }
        }
    }

    private fun generateWavHeader(pcmSize: Int, sampleRate: Int = 22050): ByteArray {
        val totalDataLen = pcmSize + 36
        val byteRate = sampleRate * 2
        val header = ByteArray(44)

        header[0] = 'R'.code.toByte()
        header[1] = 'I'.code.toByte()
        header[2] = 'F'.code.toByte()
        header[3] = 'F'.code.toByte()
        header[4] = (totalDataLen and 0xff).toByte()
        header[5] = ((totalDataLen shr 8) and 0xff).toByte()
        header[6] = ((totalDataLen shr 16) and 0xff).toByte()
        header[7] = ((totalDataLen shr 24) and 0xff).toByte()
        header[8] = 'W'.code.toByte()
        header[9] = 'A'.code.toByte()
        header[10] = 'V'.code.toByte()
        header[11] = 'E'.code.toByte()
        header[12] = 'f'.code.toByte()
        header[13] = 'm'.code.toByte()
        header[14] = 't'.code.toByte()
        header[15] = ' '.code.toByte()
        header[16] = 16
        header[17] = 0
        header[18] = 0
        header[19] = 0
        header[20] = 1
        header[21] = 0
        header[22] = 1
        header[23] = 0
        header[24] = (sampleRate and 0xff).toByte()
        header[25] = ((sampleRate shr 8) and 0xff).toByte()
        header[26] = ((sampleRate shr 16) and 0xff).toByte()
        header[27] = ((sampleRate shr 24) and 0xff).toByte()
        header[28] = (byteRate and 0xff).toByte()
        header[29] = ((byteRate shr 8) and 0xff).toByte()
        header[30] = ((byteRate shr 16) and 0xff).toByte()
        header[31] = ((byteRate shr 24) and 0xff).toByte()
        header[32] = 2
        header[33] = 0
        header[34] = 16
        header[35] = 0
        header[36] = 'd'.code.toByte()
        header[37] = 'a'.code.toByte()
        header[38] = 't'.code.toByte()
        header[39] = 'a'.code.toByte()
        header[40] = (pcmSize and 0xff).toByte()
        header[41] = ((pcmSize shr 8) and 0xff).toByte()
        header[42] = ((pcmSize shr 16) and 0xff).toByte()
        header[43] = ((pcmSize shr 24) and 0xff).toByte()

        return header
    }

    private fun generatePcmSineWave(frequency: Float, durationSec: Float): ByteArray {
        val sampleRate = 22050
        val numSamples = (durationSec * sampleRate).toInt()
        val pcmData = ByteArray(numSamples * 2)

        for (i in 0 until numSamples) {
            val time = i.toDouble() / sampleRate
            val envelope = (1.0 - (i.toDouble() / numSamples)) // Decay envelope
            val wave = sin(2.0 * Math.PI * frequency * time) * envelope
            val shortSample = (wave * 28000).toInt().coerceIn(-32768, 32767).toShort()

            pcmData[i * 2] = (shortSample.toInt() and 0x00FF).toByte()
            pcmData[i * 2 + 1] = ((shortSample.toInt() and 0xFF00) shr 8).toByte()
        }
        return pcmData
    }

    fun onCollision(intensity: Float, timestampMs: Long) {
        if (config.isMuted) return

        // Respect Cooldown
        if (timestampMs - lastTriggerTimeMs < config.collisionCooldownMs) {
            return
        }
        lastTriggerTimeMs = timestampMs

        when (config.audioMode) {
            AudioMode.COLLISION_MODE -> {
                playNextBeatNote(intensity)
            }
            AudioMode.PLAYLIST_MODE -> {
                playNextBeatNote(intensity)
            }
            AudioMode.LOOP_MODE -> {
                playNextBeatNote(1.0f)
            }
            AudioMode.RANDOM_MODE -> {
                val randomIndex = (0 until pentatonicScale.size).random()
                playSynthesizedNote(pentatonicScale[randomIndex], intensity)
            }
        }
    }

    private fun playNextBeatNote(intensity: Float) {
        val freq = pentatonicScale[currentBeatIndex % pentatonicScale.size]
        currentBeatIndex = (currentBeatIndex + 1) % pentatonicScale.size
        playSynthesizedNote(freq, intensity)
    }

    private fun playSynthesizedNote(frequency: Float, intensity: Float) {
        if (config.isMuted) return
        val effectiveVol = (config.volume * intensity.coerceIn(0.2f, 1.0f)).coerceIn(0f, 1f)
        val pitchRate = (config.pitch * config.playbackSpeed).coerceIn(0.5f, 2.0f)

        val closestFreq = pentatonicScale.minByOrNull { kotlin.math.abs(it - frequency) } ?: pentatonicScale[0]
        val soundId = freqSoundMap[closestFreq]
        if (soundId != null && soundId > 0) {
            soundPool?.play(soundId, effectiveVol, effectiveVol, 1, 0, pitchRate)
        }
    }

    fun release() {
        soundPool?.release()
        soundPool = null
        freqSoundMap.clear()
    }
}
