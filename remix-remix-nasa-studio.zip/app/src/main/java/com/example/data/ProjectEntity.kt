package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val templateType: String,
    val objectCount: Int,
    val ringCount: Int,
    val rotationSpeed: Float,
    val bounce: Float,
    val gravityY: Float,
    val gapAngleDegrees: Float,
    val primaryColorHex: String,
    val secondaryColorHex: String,
    val audioMode: String,
    val durationSeconds: Int,
    val lastModified: Long = System.currentTimeMillis()
)
