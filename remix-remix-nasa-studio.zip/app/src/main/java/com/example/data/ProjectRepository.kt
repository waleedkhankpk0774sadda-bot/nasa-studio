package com.example.data

import kotlinx.coroutines.flow.Flow

class ProjectRepository(private val projectDao: ProjectDao) {
    val allProjects: Flow<List<ProjectEntity>> = projectDao.getAllProjects()

    suspend fun getProjectById(id: Long): ProjectEntity? = projectDao.getProjectById(id)

    suspend fun insert(project: ProjectEntity): Long = projectDao.insertProject(project)

    suspend fun deleteById(id: Long) = projectDao.deleteProjectById(id)
}
