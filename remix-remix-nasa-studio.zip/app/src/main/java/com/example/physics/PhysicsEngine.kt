package com.example.physics

import androidx.compose.ui.graphics.Color
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.*
import kotlin.random.Random

class PhysicsEngine(var config: PhysicsConfig = PhysicsConfig()) {

    private val bodyIdCounter = AtomicLong(1L)
    val bodies = mutableListOf<PhysicsBody>()
    val rings = mutableListOf<RingConstraint>()
    val particles = mutableListOf<Particle>()
    val collisionEvents = mutableListOf<CollisionEvent>()

    var simulationTimeMs: Long = 0L
    var isRunning: Boolean = false
    var totalEscapedCount: Int = 0

    // Center of simulation canvas
    var centerX: Float = 540f
    var centerY: Float = 960f

    init {
        resetSimulation()
    }

    fun updateCanvasCenter(w: Float, h: Float) {
        if (w > 0 && h > 0) {
            centerX = w / 2f
            centerY = h / 2f
        }
    }

    fun resetSimulation() {
        bodies.clear()
        rings.clear()
        particles.clear()
        collisionEvents.clear()
        bodyIdCounter.set(1L)
        simulationTimeMs = 0L
        totalEscapedCount = 0

        setupRings()
        setupBodies()
    }

    private fun setupRings() {
        val count = config.ringCount.coerceIn(1, 5)
        val gapRad = Math.toRadians(config.gapAngleDegrees.toDouble()).toFloat()
        
        for (i in 0 until count) {
            val radius = config.outerRingRadius * ((count - i).toFloat() / count.toFloat())
            val rotSpeed = (config.rotationSpeed * 0.015f * (if (i % 2 == 0) config.rotationDirection else -config.rotationDirection))
            
            // Alternate gap starting angles
            val initialGapCenter = (i * (PI / 2.0)).toFloat()
            
            val ringColor = when (i % 4) {
                0 -> config.ringColor
                1 -> Color(0xFF00E5FF)
                2 -> Color(0xFFFF007A)
                else -> Color(0xFFFFB800)
            }

            rings.add(
                RingConstraint(
                    id = i + 1,
                    radius = radius,
                    thickness = config.ringThickness,
                    rotationAngle = initialGapCenter,
                    rotationSpeed = rotSpeed,
                    rotationDirection = if (i % 2 == 0) config.rotationDirection else -config.rotationDirection,
                    gapAngleCenter = initialGapCenter,
                    gapWidthAngle = gapRad,
                    color = ringColor
                )
            )
        }
    }

    private fun setupBodies() {
        val count = config.objectCount.coerceIn(1, 200)
        val rand = Random(System.currentTimeMillis())

        when (config.templateType) {
            TemplateType.ROTATING_RINGS_BALLS -> {
                for (i in 0 until count) {
                    val angle = rand.nextFloat() * 2f * PI.toFloat()
                    val dist = rand.nextFloat() * (config.outerRingRadius * 0.4f)
                    val bx = centerX + cos(angle) * dist
                    val by = centerY + sin(angle) * dist
                    val speed = 50f + rand.nextFloat() * 150f
                    val dirAngle = rand.nextFloat() * 2f * PI.toFloat()

                    val color = if (i % 2 == 0) config.primaryObjectColor else config.secondaryObjectColor

                    bodies.add(
                        PhysicsBody(
                            id = bodyIdCounter.getAndIncrement(),
                            x = bx,
                            y = by,
                            vx = cos(dirAngle) * speed,
                            vy = sin(dirAngle) * speed,
                            radius = config.objectSize,
                            shapeType = ShapeType.CIRCLE,
                            color = color
                        )
                    )
                }
            }

            TemplateType.EMOJI_FLAG_CIRCLES -> {
                val emojis = config.customEmojis.ifEmpty { listOf("🚀", "⭐", "🇺🇸", "🪐") }
                for (i in 0 until count) {
                    val emoji = emojis[i % emojis.size]
                    val angle = rand.nextFloat() * 2f * PI.toFloat()
                    val dist = rand.nextFloat() * (config.outerRingRadius * 0.4f)
                    val bx = centerX + cos(angle) * dist
                    val by = centerY + sin(angle) * dist
                    val speed = 80f + rand.nextFloat() * 120f
                    val dirAngle = rand.nextFloat() * 2f * PI.toFloat()

                    bodies.add(
                        PhysicsBody(
                            id = bodyIdCounter.getAndIncrement(),
                            x = bx,
                            y = by,
                            vx = cos(dirAngle) * speed,
                            vy = sin(dirAngle) * speed,
                            radius = config.objectSize * 1.2f,
                            shapeType = ShapeType.EMOJI,
                            label = emoji,
                            color = config.primaryObjectColor
                        )
                    )
                }
            }

            TemplateType.TEXT_CHARACTERS -> {
                val text = config.customText.ifEmpty { "NASA" }
                val letters = text.toCharArray().filter { !it.isWhitespace() }
                val totalTextBodies = if (letters.isNotEmpty()) {
                    count.coerceAtLeast(letters.size)
                } else count

                for (i in 0 until totalTextBodies) {
                    val charStr = if (letters.isNotEmpty()) letters[i % letters.size].toString() else "A"
                    val angle = rand.nextFloat() * 2f * PI.toFloat()
                    val dist = rand.nextFloat() * (config.outerRingRadius * 0.35f)
                    val bx = centerX + cos(angle) * dist
                    val by = centerY + sin(angle) * dist

                    bodies.add(
                        PhysicsBody(
                            id = bodyIdCounter.getAndIncrement(),
                            x = bx,
                            y = by,
                            vx = (rand.nextFloat() - 0.5f) * 200f,
                            vy = (rand.nextFloat() - 0.5f) * 200f,
                            radius = config.objectSize * 1.1f,
                            shapeType = ShapeType.TEXT_LETTER,
                            label = charStr,
                            color = if (i % 3 == 0) Color(0xFFFFB800) else config.primaryObjectColor
                        )
                    )
                }
            }

            TemplateType.IMAGE_OBJECTS -> {
                for (i in 0 until count) {
                    val angle = rand.nextFloat() * 2f * PI.toFloat()
                    val dist = rand.nextFloat() * (config.outerRingRadius * 0.4f)
                    val bx = centerX + cos(angle) * dist
                    val by = centerY + sin(angle) * dist

                    bodies.add(
                        PhysicsBody(
                            id = bodyIdCounter.getAndIncrement(),
                            x = bx,
                            y = by,
                            vx = (rand.nextFloat() - 0.5f) * 180f,
                            vy = (rand.nextFloat() - 0.5f) * 180f,
                            radius = config.objectSize * 1.3f,
                            shapeType = ShapeType.IMAGE_SPRITE,
                            label = "IMG",
                            color = config.secondaryObjectColor
                        )
                    )
                }
            }

            TemplateType.CUSTOM_OBJECTS -> {
                val shape = config.selectedShape
                for (i in 0 until count) {
                    val angle = rand.nextFloat() * 2f * PI.toFloat()
                    val dist = rand.nextFloat() * (config.outerRingRadius * 0.4f)
                    val bx = centerX + cos(angle) * dist
                    val by = centerY + sin(angle) * dist

                    bodies.add(
                        PhysicsBody(
                            id = bodyIdCounter.getAndIncrement(),
                            x = bx,
                            y = by,
                            vx = (rand.nextFloat() - 0.5f) * 220f,
                            vy = (rand.nextFloat() - 0.5f) * 220f,
                            radius = config.objectSize,
                            shapeType = shape,
                            label = if (shape == ShapeType.EMOJI) "⭐" else "",
                            color = when (i % 3) {
                                0 -> config.primaryObjectColor
                                1 -> config.secondaryObjectColor
                                else -> Color(0xFFFF00E5)
                            }
                        )
                    )
                }
            }
        }
    }

    /**
     * Advances simulation by exact step dt (in seconds).
     * Uses substepping for numerical stability.
     */
    fun step(dtSeconds: Float) {
        val substeps = 4
        val subDt = dtSeconds / substeps

        for (s in 0 until substeps) {
            subStep(subDt)
        }

        simulationTimeMs += (dtSeconds * 1000f).toLong()

        // Update trail points & particles
        updateParticles(dtSeconds)
        updateTrails()
    }

    private fun subStep(dt: Float) {
        // 1. Rotate rings
        for (ring in rings) {
            ring.rotationAngle += ring.rotationSpeed * ring.rotationDirection
            // Keep rotationAngle normalized 0..2PI
            if (ring.rotationAngle > 2 * PI) ring.rotationAngle -= (2 * PI).toFloat()
            if (ring.rotationAngle < 0) ring.rotationAngle += (2 * PI).toFloat()
            ring.gapAngleCenter = ring.rotationAngle
        }

        // 2. Update body positions
        for (body in bodies) {
            // Apply Gravity
            body.vx += config.gravityX * dt
            body.vy += config.gravityY * dt

            // Apply Air Damping / Friction
            body.vx *= config.friction
            body.vy *= config.friction

            // Update position
            body.x += body.vx * dt
            body.y += body.vy * dt

            // Update rotation
            body.rotationAngle += body.angularVelocity * dt
        }

        // 3. Collision with Rings (Internal concentric containment boundaries with gaps)
        for (body in bodies) {
            // Distance from ring center
            val dx = body.x - centerX
            val dy = body.y - centerY
            val dist = sqrt(dx * dx + dy * dy)

            // Angle of body relative to center
            var bodyAngle = atan2(dy, dx)
            if (bodyAngle < 0) bodyAngle += (2 * PI).toFloat()

            for (ring in rings) {
                // Check if body is near ring radius
                val ringMinR = ring.radius - ring.thickness / 2f
                val ringMaxR = ring.radius + ring.thickness / 2f

                if (dist + body.radius >= ringMinR && dist - body.radius <= ringMaxR) {
                    // Check if collision angle falls inside ring gap arc
                    val isInsideGap = isAngleInGap(bodyAngle, ring.gapAngleCenter, ring.gapWidthAngle)

                    if (!isInsideGap) {
                        // Solid ring boundary collision!
                        val normalX = dx / if (dist > 0) dist else 1f
                        val normalY = dy / if (dist > 0) dist else 1f

                        // Calculate relative velocity
                        val dot = body.vx * normalX + body.vy * normalY

                        if (dist < ring.radius && dot > 0) {
                            // Hitting inner wall
                            body.x = centerX + normalX * (ring.radius - body.radius - 1f)
                            body.vx -= (1f + config.bounce) * dot * normalX
                            body.vy -= (1f + config.bounce) * dot * normalY

                            triggerCollisionEffect(body.x, body.y, abs(dot), body.id)
                        } else if (dist >= ring.radius && dot < 0) {
                            // Hitting outer wall
                            body.x = centerX + normalX * (ring.radius + body.radius + 1f)
                            body.vx -= (1f + config.bounce) * dot * normalX
                            body.vy -= (1f + config.bounce) * dot * normalY

                            triggerCollisionEffect(body.x, body.y, abs(dot), body.id)
                        }
                    } else {
                        // Body passed through gap!
                        if (dist > ring.radius + body.radius && !body.isEscaped) {
                            body.isEscaped = true
                            totalEscapedCount++
                        }
                    }
                }
            }

            // Outer Canvas Boundary Box (So escaped balls bounce around screen instead of disappearing forever)
            val margin = body.radius
            if (body.x - margin < centerX - 480f) {
                body.x = centerX - 480f + margin
                body.vx = -body.vx * config.bounce
            } else if (body.x + margin > centerX + 480f) {
                body.x = centerX + 480f - margin
                body.vx = -body.vx * config.bounce
            }

            if (body.y - margin < centerY - 720f) {
                body.y = centerY - 720f + margin
                body.vy = -body.vy * config.bounce
            } else if (body.y + margin > centerY + 720f) {
                body.y = centerY + 720f - margin
                body.vy = -body.vy * config.bounce
            }
        }

        // 4. Body to Body Collisions
        val size = bodies.size
        for (i in 0 until size) {
            val b1 = bodies[i]
            for (j in i + 1 until size) {
                val b2 = bodies[j]

                val dx = b2.x - b1.x
                val dy = b2.y - b1.y
                val distSq = dx * dx + dy * dy
                val minDist = b1.radius + b2.radius

                if (distSq < minDist * minDist && distSq > 0.0001f) {
                    val dist = sqrt(distSq)
                    val overlap = minDist - dist

                    // Normal vector
                    val nx = dx / dist
                    val ny = dy / dist

                    // Separate bodies to prevent overlap
                    val separateAmount = overlap * 0.5f
                    b1.x -= nx * separateAmount
                    b1.y -= ny * separateAmount
                    b2.x += nx * separateAmount
                    b2.y += ny * separateAmount

                    // Relative velocity
                    val rvx = b2.vx - b1.vx
                    val rvy = b2.vy - b1.vy
                    val velAlongNormal = rvx * nx + rvy * ny

                    // Only bounce if bodies are moving towards each other
                    if (velAlongNormal < 0) {
                        val restitution = config.bounce
                        val impulseMagnitude = -(1f + restitution) * velAlongNormal / (1f / b1.mass + 1f / b2.mass)

                        val impulseX = impulseMagnitude * nx
                        val impulseY = impulseMagnitude * ny

                        b1.vx -= impulseX / b1.mass
                        b1.vy -= impulseY / b1.mass
                        b2.vx += impulseX / b2.mass
                        b2.vy += impulseY / b2.mass

                        val collisionImpact = abs(velAlongNormal)
                        val colX = (b1.x + b2.x) / 2f
                        val colY = (b1.y + b2.y) / 2f
                        triggerCollisionEffect(colX, colY, collisionImpact, b1.id, b2.id)
                    }
                }
            }
        }
    }

    private fun isAngleInGap(angle: Float, gapCenter: Float, gapWidth: Float): Boolean {
        var diff = abs(angle - gapCenter)
        while (diff > PI) diff = abs(diff - (2 * PI).toFloat())
        return diff <= gapWidth / 2f
    }

    private fun triggerCollisionEffect(x: Float, y: Float, impact: Float, b1Id: Long, b2Id: Long? = null) {
        if (impact > 15f) {
            collisionEvents.add(
                CollisionEvent(
                    x = x,
                    y = y,
                    intensity = (impact / 300f).coerceIn(0.1f, 1.0f),
                    bodyId1 = b1Id,
                    bodyId2 = b2Id,
                    timestampMs = simulationTimeMs
                )
            )

            // Spawn visual particles if enabled
            if (config.particleEffects) {
                val particleCount = (impact / 20f).toInt().coerceIn(3, 12)
                val rand = Random(System.currentTimeMillis())
                for (p in 0 until particleCount) {
                    val pAngle = rand.nextFloat() * 2f * PI.toFloat()
                    val pSpeed = 40f + rand.nextFloat() * 180f
                    particles.add(
                        Particle(
                            x = x,
                            y = y,
                            vx = cos(pAngle) * pSpeed,
                            vy = sin(pAngle) * pSpeed,
                            alpha = 1.0f,
                            size = 3f + rand.nextFloat() * 6f,
                            color = if (rand.nextBoolean()) config.primaryObjectColor else config.secondaryObjectColor,
                            maxLife = 20 + rand.nextInt(20)
                        )
                    )
                }
            }
        }
    }

    private fun updateParticles(dt: Float) {
        val iterator = particles.iterator()
        while (iterator.hasNext()) {
            val p = iterator.next()
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.currentLife++
            p.alpha = 1.0f - (p.currentLife.toFloat() / p.maxLife.toFloat())
            if (p.currentLife >= p.maxLife) {
                iterator.remove()
            }
        }
    }

    private fun updateTrails() {
        if (!config.trailEffect) return
        for (b in bodies) {
            b.trailHistory.add(0, TrailPoint(b.x, b.y, 0.8f))
            if (b.trailHistory.size > 8) {
                b.trailHistory.removeAt(b.trailHistory.size - 1)
            }
        }
    }

    fun spawnObjectAt(x: Float, y: Float) {
        val rand = Random(System.currentTimeMillis())
        val speed = 100f + rand.nextFloat() * 150f
        val angle = rand.nextFloat() * 2f * PI.toFloat()

        bodies.add(
            PhysicsBody(
                id = bodyIdCounter.getAndIncrement(),
                x = x,
                y = y,
                vx = cos(angle) * speed,
                vy = sin(angle) * speed,
                radius = config.objectSize,
                shapeType = config.selectedShape,
                label = if (config.selectedShape == ShapeType.TEXT_LETTER) "A" else if (config.selectedShape == ShapeType.EMOJI) "⭐" else "",
                color = config.primaryObjectColor
            )
        )
    }
}
