package com.example.physics

import androidx.compose.ui.graphics.Color
import kotlin.math.PI

enum class TemplateType {
    ROTATING_RINGS_BALLS,
    EMOJI_FLAG_CIRCLES,
    TEXT_CHARACTERS,
    IMAGE_OBJECTS,
    CUSTOM_OBJECTS
}

enum class ShapeType {
    CIRCLE,
    SQUARE,
    TRIANGLE,
    STAR,
    EMOJI,
    TEXT_LETTER,
    IMAGE_SPRITE
}

enum class BackgroundType {
    SOLID,
    RADIAL_GRADIENT,
    LINEAR_GRADIENT,
    NEON_GRID,
    SPACE_NEBULA
}

data class PhysicsBody(
    val id: Long,
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var radius: Float,
    val shapeType: ShapeType,
    val label: String = "",
    val color: Color = Color.Cyan,
    val mass: Float = 1.0f,
    var rotationAngle: Float = 0f,
    var angularVelocity: Float = 0f,
    var isEscaped: Boolean = false,
    val trailHistory: MutableList<TrailPoint> = mutableListOf()
)

data class TrailPoint(
    val x: Float,
    val y: Float,
    val alpha: Float,
    val timestamp: Long = System.currentTimeMillis()
)

data class RingConstraint(
    val id: Int,
    var radius: Float,
    var thickness: Float,
    var rotationAngle: Float,
    var rotationSpeed: Float, // Radians per frame / second
    var rotationDirection: Int = 1, // 1 for CW, -1 for CCW
    var gapAngleCenter: Float, // Angle in radians where gap center is located
    var gapWidthAngle: Float,  // Width of gap in radians (e.g. 0.5 rad ≈ 28 deg)
    val color: Color = Color(0xFF00E5FF)
)

data class Particle(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var alpha: Float,
    var size: Float,
    val color: Color,
    var maxLife: Int,
    var currentLife: Int = 0
)

data class PhysicsConfig(
    val templateType: TemplateType = TemplateType.ROTATING_RINGS_BALLS,
    val objectCount: Int = 20,
    val ringCount: Int = 2,
    val ringThickness: Float = 12f,
    val outerRingRadius: Float = 320f,
    val gapAngleDegrees: Float = 45f,
    val gravityX: Float = 0f,
    val gravityY: Float = 980f, // Pixels per sec^2
    val bounce: Float = 0.85f,   // Restitution
    val friction: Float = 0.995f, // Air damping
    val elasticity: Float = 0.9f,
    val rotationSpeed: Float = 1.2f, // RPM or rad/s multiplier
    val rotationDirection: Int = 1,
    val objectSize: Float = 18f,
    val customText: String = "NASA STUDIO",
    val customEmojis: List<String> = listOf("🚀", "🪐", "⭐", "🌕", "🛸", "🌍", "🇺🇸", "🇨🇦", "🇬🇧", "🇯🇵"),
    val selectedShape: ShapeType = ShapeType.CIRCLE,
    val glowEffect: Boolean = true,
    val trailEffect: Boolean = true,
    val motionBlur: Boolean = false,
    val particleEffects: Boolean = true,
    val shadowEffect: Boolean = true,
    val backgroundColor: Color = Color(0xFF0A0E1A),
    val primaryObjectColor: Color = Color(0xFF00F0FF),
    val secondaryObjectColor: Color = Color(0xFFFF007A),
    val ringColor: Color = Color(0xFF7928CA),
    val backgroundType: BackgroundType = BackgroundType.NEON_GRID,
    val simulationDurationSeconds: Int = 15,
    val targetFps: Int = 60
)

data class CollisionEvent(
    val x: Float,
    val y: Float,
    val intensity: Float,
    val bodyId1: Long,
    val bodyId2: Long? = null,
    val timestampMs: Long
)
