package com.example.ui

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.screens.*
import com.example.ui.theme.NASAStudioTheme
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SpaceBlack
import com.example.ui.theme.SurfaceDark

data class NavTabItem(
    val title: String,
    val icon: ImageVector,
    val tag: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContent(viewModel: StudioViewModel) {
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val isStudioActive by viewModel.isStudioActive.collectAsStateWithLifecycle()
    val physicsConfig by viewModel.physicsConfig.collectAsStateWithLifecycle()
    val audioConfig by viewModel.audioConfig.collectAsStateWithLifecycle()
    val renderSettings by viewModel.renderSettings.collectAsStateWithLifecycle()
    val renderProgress by viewModel.renderProgress.collectAsStateWithLifecycle()
    val isRenderingVideo by viewModel.isRenderingVideo.collectAsStateWithLifecycle()
    val showCompleteDialog by viewModel.showSimulationCompleteDialog.collectAsStateWithLifecycle()
    val exportedFile by viewModel.lastExportedVideoFile.collectAsStateWithLifecycle()
    val savedProjects by viewModel.savedProjects.collectAsStateWithLifecycle()

    val navTabs = listOf(
        NavTabItem("Templates", Icons.Default.Science, "tab_templates"),
        NavTabItem("My Projects", Icons.Default.Folder, "tab_projects"),
        NavTabItem("Audio", Icons.Default.MusicNote, "tab_audio"),
        NavTabItem("Export", Icons.Default.Movie, "tab_export"),
        NavTabItem("Settings", Icons.Default.Settings, "tab_settings")
    )

    NASAStudioTheme {
        if (isStudioActive) {
            // Full-screen Simulation Studio Mode
            SimulationStudioScreen(
                physicsEngine = viewModel.physicsEngine,
                config = physicsConfig,
                onConfigChange = { viewModel.updatePhysicsConfig(it) },
                onCloseStudio = { viewModel.closeStudio() },
                onStartRender = { viewModel.startRenderingVideo() },
                onSaveProject = { title -> viewModel.saveCurrentProject(title) },
                isRendering = isRenderingVideo,
                renderProgress = renderProgress,
                showCompleteDialog = showCompleteDialog,
                onDismissCompleteDialog = { viewModel.dismissSimulationCompleteDialog() },
                exportedFile = exportedFile,
                onTriggerCollisionSound = { intensity, timestamp ->
                    viewModel.audioEngine.onCollision(intensity, timestamp)
                }
            )
        } else {
            // Standard Tabbed M3 Interface
            Scaffold(
                topBar = {
                    CenterAlignedTopAppBar(
                        title = {
                            Row {
                                Text(
                                    text = "NASA ",
                                    color = NeonCyan,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 20.sp
                                )
                                Text(
                                    text = "STUDIO",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp
                                )
                            }
                        },
                        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                            containerColor = SpaceBlack
                        )
                    )
                },
                bottomBar = {
                    NavigationBar(
                        containerColor = SurfaceDark,
                        windowInsets = WindowInsets.navigationBars
                    ) {
                        navTabs.forEachIndexed { index, tab ->
                            NavigationBarItem(
                                selected = selectedTab == index,
                                onClick = { viewModel.setTab(index) },
                                icon = {
                                    Icon(
                                        imageVector = tab.icon,
                                        contentDescription = tab.title,
                                        tint = if (selectedTab == index) NeonCyan else Color.White.copy(alpha = 0.6f)
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.title,
                                        color = if (selectedTab == index) NeonCyan else Color.White.copy(alpha = 0.6f),
                                        fontSize = 11.sp,
                                        fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                modifier = Modifier.testTag(tab.tag)
                            )
                        }
                    }
                },
                containerColor = SpaceBlack
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    Crossfade(targetState = selectedTab, label = "TabSwitch") { tabIndex ->
                        when (tabIndex) {
                            0 -> TemplatesScreen(
                                onSelectTemplate = { type ->
                                    viewModel.openStudioWithTemplate(type)
                                }
                            )
                            1 -> ProjectsScreen(
                                projects = savedProjects,
                                onLoadProject = { project ->
                                    viewModel.loadSavedProject(project)
                                },
                                onDeleteProject = { project ->
                                    viewModel.deleteProject(project)
                                }
                            )
                            2 -> AudioStudioScreen(
                                config = audioConfig,
                                onConfigChange = { viewModel.updateAudioConfig(it) },
                                onTestSound = {
                                    viewModel.audioEngine.onCollision(1.0f, System.currentTimeMillis())
                                }
                            )
                            3 -> ExportStudioScreen(
                                renderSettings = renderSettings,
                                onRenderSettingsChange = { viewModel.updateRenderSettings(it) },
                                isRendering = isRenderingVideo,
                                renderProgress = renderProgress,
                                lastExportedFile = exportedFile,
                                onStartRender = {
                                    viewModel.openStudioWithTemplate(physicsConfig.templateType)
                                    viewModel.startRenderingVideo()
                                }
                            )
                            4 -> SettingsScreen()
                        }
                    }
                }
            }
        }
    }
}
