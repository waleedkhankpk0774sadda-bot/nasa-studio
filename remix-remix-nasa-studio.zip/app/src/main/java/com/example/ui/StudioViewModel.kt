package com.example.ui

import android.app.Application
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioConfig
import com.example.audio.AudioEngine
import com.example.data.AppDatabase
import com.example.data.ProjectEntity
import com.example.data.ProjectRepository
import com.example.physics.PhysicsConfig
import com.example.physics.PhysicsEngine
import com.example.physics.TemplateType
import com.example.video.RenderProgress
import com.example.video.RenderSettings
import com.example.video.VideoRenderEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

class StudioViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ProjectRepository
    val audioEngine: AudioEngine = AudioEngine(application)
    val videoRenderEngine: VideoRenderEngine = VideoRenderEngine(application)
    val physicsEngine: PhysicsEngine

    private val _selectedTab = MutableStateFlow(0) // 0: Templates, 1: Projects, 2: Audio, 3: Export, 4: Settings
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    private val _physicsConfig = MutableStateFlow(PhysicsConfig())
    val physicsConfig: StateFlow<PhysicsConfig> = _physicsConfig.asStateFlow()

    private val _audioConfig = MutableStateFlow(AudioConfig())
    val audioConfig: StateFlow<AudioConfig> = _audioConfig.asStateFlow()

    private val _renderSettings = MutableStateFlow(RenderSettings())
    val renderSettings: StateFlow<RenderSettings> = _renderSettings.asStateFlow()

    private val _renderProgress = MutableStateFlow<RenderProgress?>(null)
    val renderProgress: StateFlow<RenderProgress?> = _renderProgress.asStateFlow()

    private val _isRenderingVideo = MutableStateFlow(false)
    val isRenderingVideo: StateFlow<Boolean> = _isRenderingVideo.asStateFlow()

    private val _isStudioActive = MutableStateFlow(false)
    val isStudioActive: StateFlow<Boolean> = _isStudioActive.asStateFlow()

    private val _showSimulationCompleteDialog = MutableStateFlow(false)
    val showSimulationCompleteDialog: StateFlow<Boolean> = _showSimulationCompleteDialog.asStateFlow()

    private val _lastExportedVideoFile = MutableStateFlow<File?>(null)
    val lastExportedVideoFile: StateFlow<File?> = _lastExportedVideoFile.asStateFlow()

    val savedProjects: StateFlow<List<ProjectEntity>>

    init {
        val projectDao = AppDatabase.getDatabase(application).projectDao()
        repository = ProjectRepository(projectDao)

        savedProjects = MutableStateFlow(emptyList())
        viewModelScope.launch {
            repository.allProjects.collect { projects ->
                (savedProjects as MutableStateFlow).value = projects
            }
        }

        physicsEngine = PhysicsEngine(_physicsConfig.value)
    }

    fun setTab(index: Int) {
        _selectedTab.value = index
    }

    fun openStudioWithTemplate(templateType: TemplateType) {
        val newConfig = when (templateType) {
            TemplateType.ROTATING_RINGS_BALLS -> PhysicsConfig(
                templateType = TemplateType.ROTATING_RINGS_BALLS,
                objectCount = 24,
                ringCount = 3,
                outerRingRadius = 320f,
                gapAngleDegrees = 40f,
                rotationSpeed = 1.2f,
                bounce = 0.88f
            )
            TemplateType.EMOJI_FLAG_CIRCLES -> PhysicsConfig(
                templateType = TemplateType.EMOJI_FLAG_CIRCLES,
                objectCount = 20,
                ringCount = 2,
                gapAngleDegrees = 50f,
                customEmojis = listOf("🚀", "🪐", "⭐", "🌕", "🛸", "🌍", "🇺🇸", "🇨🇦", "🇬🇧", "🇯🇵")
            )
            TemplateType.TEXT_CHARACTERS -> PhysicsConfig(
                templateType = TemplateType.TEXT_CHARACTERS,
                objectCount = 20,
                ringCount = 2,
                customText = "NASA STUDIO PHYSICS"
            )
            TemplateType.IMAGE_OBJECTS -> PhysicsConfig(
                templateType = TemplateType.IMAGE_OBJECTS,
                objectCount = 18,
                ringCount = 2
            )
            TemplateType.CUSTOM_OBJECTS -> PhysicsConfig(
                templateType = TemplateType.CUSTOM_OBJECTS,
                objectCount = 25,
                ringCount = 2
            )
        }
        _physicsConfig.value = newConfig
        physicsEngine.config = newConfig
        physicsEngine.resetSimulation()
        _isStudioActive.value = true
    }

    fun updatePhysicsConfig(newConfig: PhysicsConfig) {
        _physicsConfig.value = newConfig
        physicsEngine.config = newConfig
        physicsEngine.resetSimulation()
    }

    fun updateAudioConfig(newConfig: AudioConfig) {
        _audioConfig.value = newConfig
        audioEngine.config = newConfig
    }

    fun updateRenderSettings(newSettings: RenderSettings) {
        _renderSettings.value = newSettings
    }

    fun closeStudio() {
        _isStudioActive.value = false
        physicsEngine.isRunning = false
    }

    fun startRenderingVideo() {
        viewModelScope.launch {
            _isRenderingVideo.value = true
            _renderProgress.value = RenderProgress(0, 100, 0f)

            val exportedFile = videoRenderEngine.renderSimulationToMp4(
                physicsConfig = _physicsConfig.value,
                renderSettings = _renderSettings.value,
                onProgress = { progress ->
                    _renderProgress.value = progress
                }
            )

            _isRenderingVideo.value = false
            _lastExportedVideoFile.value = exportedFile

            if (exportedFile != null) {
                _showSimulationCompleteDialog.value = true
            }
        }
    }

    fun dismissSimulationCompleteDialog() {
        _showSimulationCompleteDialog.value = false
    }

    fun saveCurrentProject(title: String = "NASA Simulation") {
        viewModelScope.launch {
            val cfg = _physicsConfig.value
            val entity = ProjectEntity(
                title = title,
                templateType = cfg.templateType.name,
                objectCount = cfg.objectCount,
                ringCount = cfg.ringCount,
                rotationSpeed = cfg.rotationSpeed,
                bounce = cfg.bounce,
                gravityY = cfg.gravityY,
                gapAngleDegrees = cfg.gapAngleDegrees,
                primaryColorHex = "#00F0FF",
                secondaryColorHex = "#FF007A",
                audioMode = _audioConfig.value.audioMode.name,
                durationSeconds = _renderSettings.value.durationSeconds
            )
            repository.insert(entity)
        }
    }

    fun loadSavedProject(project: ProjectEntity) {
        val templateType = try {
            TemplateType.valueOf(project.templateType)
        } catch (e: Exception) {
            TemplateType.ROTATING_RINGS_BALLS
        }

        val config = PhysicsConfig(
            templateType = templateType,
            objectCount = project.objectCount,
            ringCount = project.ringCount,
            rotationSpeed = project.rotationSpeed,
            bounce = project.bounce,
            gravityY = project.gravityY,
            gapAngleDegrees = project.gapAngleDegrees
        )
        updatePhysicsConfig(config)
        _isStudioActive.value = true
    }

    fun deleteProject(project: ProjectEntity) {
        viewModelScope.launch {
            repository.deleteById(project.id)
        }
    }
}
