package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AudioConfig
import com.example.audio.AudioMode
import com.example.audio.SoundPreset
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.SurfaceDark

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioStudioScreen(
    config: AudioConfig,
    onConfigChange: (AudioConfig) -> Unit,
    onTestSound: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = "Audio",
                    tint = NeonCyan,
                    modifier = Modifier.size(32.dp)
                )

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "Collision Sound Studio",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "Configure collision sound triggers & audio synth modes",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 13.sp
                    )
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "AUDIO MODE",
                        color = NeonCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    AudioMode.values().forEach { mode ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = config.audioMode == mode,
                                onClick = { onConfigChange(config.copy(audioMode = mode)) },
                                colors = RadioButtonDefaults.colors(selectedColor = NeonCyan)
                            )
                            Text(
                                text = when (mode) {
                                    AudioMode.COLLISION_MODE -> "Collision Mode (Collision 1→Beat 1, Collision 2→Beat 2...)"
                                    AudioMode.PLAYLIST_MODE -> "Playlist Mode (Sequential background sequence)"
                                    AudioMode.LOOP_MODE -> "Loop Mode (Continuous loop)"
                                    AudioMode.RANDOM_MODE -> "Random Mode (Random pitch/tone on impact)"
                                },
                                color = Color.White,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "SOUND INSTRUMENT PRESET",
                        color = NeonPink,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SoundPreset.values().forEach { preset ->
                            FilterChip(
                                selected = config.preset == preset,
                                onClick = { onConfigChange(config.copy(preset = preset)) },
                                label = {
                                    Text(
                                        text = preset.name.replace("_", " "),
                                        fontSize = 11.sp
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NeonPink,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "AUDIO PARAMETERS & OVERLAP COOLDOWN",
                        color = NeonPurple,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Volume
                    Text(
                        text = "Volume: ${(config.volume * 100).toInt()}%",
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Slider(
                        value = config.volume,
                        onValueChange = { onConfigChange(config.copy(volume = it)) },
                        valueRange = 0f..1f,
                        colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Pitch
                    Text(
                        text = "Pitch: ${String.format("%.2f", config.pitch)}x",
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Slider(
                        value = config.pitch,
                        onValueChange = { onConfigChange(config.copy(pitch = it)) },
                        valueRange = 0.5f..2.0f,
                        colors = SliderDefaults.colors(thumbColor = NeonPink, activeTrackColor = NeonPink)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Playback Speed
                    Text(
                        text = "Playback Speed: ${String.format("%.2f", config.playbackSpeed)}x",
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Slider(
                        value = config.playbackSpeed,
                        onValueChange = { onConfigChange(config.copy(playbackSpeed = it)) },
                        valueRange = 0.5f..2.0f,
                        colors = SliderDefaults.colors(thumbColor = NeonPurple, activeTrackColor = NeonPurple)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Collision Cooldown
                    Text(
                        text = "Collision Cooldown: ${config.collisionCooldownMs} ms (Prevents sound overlap)",
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Slider(
                        value = config.collisionCooldownMs.toFloat(),
                        onValueChange = { onConfigChange(config.copy(collisionCooldownMs = it.toLong())) },
                        valueRange = 20f..300f,
                        colors = SliderDefaults.colors(thumbColor = Color(0xFFFFB800), activeTrackColor = Color(0xFFFFB800))
                    )
                }
            }
        }

        item {
            Button(
                onClick = onTestSound,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("test_audio_trigger_button"),
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.GraphicEq,
                    contentDescription = "Test",
                    tint = Color.Black
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Test Collision Beat Note",
                    color = Color.Black,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}
