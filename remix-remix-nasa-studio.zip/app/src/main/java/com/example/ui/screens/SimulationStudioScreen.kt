package com.example.ui.screens

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.physics.PhysicsConfig
import com.example.physics.PhysicsEngine
import com.example.physics.ShapeType
import com.example.physics.TemplateType
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.SpaceBlack
import com.example.ui.theme.SurfaceDark
import com.example.video.RenderProgress
import kotlinx.coroutines.delay
import java.io.File
import kotlin.math.PI

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimulationStudioScreen(
    physicsEngine: PhysicsEngine,
    config: PhysicsConfig,
    onConfigChange: (PhysicsConfig) -> Unit,
    onCloseStudio: () -> Unit,
    onStartRender: () -> Unit,
    onSaveProject: (String) -> Unit,
    isRendering: Boolean,
    renderProgress: RenderProgress?,
    showCompleteDialog: Boolean,
    onDismissCompleteDialog: () -> Unit,
    exportedFile: File?,
    onTriggerCollisionSound: (Float, Long) -> Unit
) {
    var isPlaying by remember { mutableStateOf(true) }
    var showControlsDrawer by remember { mutableStateOf(false) }
    var selectedDrawerTab by remember { mutableStateOf(0) } // 0: Objects, 1: Rings & Physics, 2: Visuals
    var projectTitleInput by remember { mutableStateOf("NASA Simulation") }
    var showSaveTitleDialog by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val textMeasurer = rememberTextMeasurer()

    // Real-time animation ticker loop
    LaunchedEffect(isPlaying) {
        var lastTime = System.currentTimeMillis()
        while (isPlaying) {
            val now = System.currentTimeMillis()
            val dt = (now - lastTime) / 1000f
            lastTime = now

            val safeDt = dt.coerceIn(0.001f, 0.05f)
            physicsEngine.step(safeDt)

            // Audio sound triggers from collision events
            var eventsProcessed = 0
            while (physicsEngine.collisionEvents.isNotEmpty() && eventsProcessed < 5) {
                val event = physicsEngine.collisionEvents.removeAt(0)
                onTriggerCollisionSound(event.intensity, event.timestampMs)
                eventsProcessed++
            }
            if (physicsEngine.collisionEvents.size > 20) {
                physicsEngine.collisionEvents.clear()
            }

            delay(16) // ~60 FPS update
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(SpaceBlack)
    ) {
        // Interactive Canvas Layer
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        physicsEngine.spawnObjectAt(offset.x, offset.y)
                    }
                }
                .testTag("simulation_physics_canvas")
        ) {
            physicsEngine.updateCanvasCenter(size.width, size.height)

            // 1. Draw Background Grid
            val gridStep = 80f
            for (x in 0..size.width.toInt() step gridStep.toInt()) {
                drawLine(
                    color = Color(0xFF152035),
                    start = Offset(x.toFloat(), 0f),
                    end = Offset(x.toFloat(), size.height),
                    strokeWidth = 1f
                )
            }
            for (y in 0..size.height.toInt() step gridStep.toInt()) {
                drawLine(
                    color = Color(0xFF152035),
                    start = Offset(0f, y.toFloat()),
                    end = Offset(size.width, y.toFloat()),
                    strokeWidth = 1f
                )
            }

            // 2. Draw Rings & Gap Openings
            for (ring in physicsEngine.rings) {
                val radius = ring.radius
                val gapStartDeg = Math.toDegrees((ring.gapAngleCenter + ring.gapWidthAngle / 2f).toDouble()).toFloat()
                val sweepDeg = 360f - Math.toDegrees(ring.gapWidthAngle.toDouble()).toFloat()

                drawArc(
                    color = ring.color,
                    startAngle = gapStartDeg,
                    sweepAngle = sweepDeg,
                    useCenter = false,
                    topLeft = Offset(physicsEngine.centerX - radius, physicsEngine.centerY - radius),
                    size = Size(radius * 2, radius * 2),
                    style = Stroke(width = ring.thickness)
                )
            }

            // 3. Draw Trail History
            if (config.trailEffect) {
                for (body in physicsEngine.bodies) {
                    for (trail in body.trailHistory) {
                        drawCircle(
                            color = body.color.copy(alpha = trail.alpha * 0.35f),
                            radius = body.radius * 0.6f,
                            center = Offset(trail.x, trail.y)
                        )
                    }
                }
            }

            // 4. Draw Particles
            for (p in physicsEngine.particles) {
                drawCircle(
                    color = p.color.copy(alpha = p.alpha),
                    radius = p.size,
                    center = Offset(p.x, p.y)
                )
            }

            // 5. Draw Physics Bodies
            for (body in physicsEngine.bodies) {
                when (body.shapeType) {
                    ShapeType.CIRCLE -> {
                        drawCircle(
                            color = body.color,
                            radius = body.radius,
                            center = Offset(body.x, body.y)
                        )
                    }
                    ShapeType.SQUARE -> {
                        val half = body.radius
                        drawRect(
                            color = body.color,
                            topLeft = Offset(body.x - half, body.y - half),
                            size = Size(half * 2, half * 2)
                        )
                    }
                    ShapeType.EMOJI, ShapeType.TEXT_LETTER -> {
                        val label = body.label.ifEmpty { "★" }
                        val textResult = textMeasurer.measure(label)
                        drawText(
                            textLayoutResult = textResult,
                            topLeft = Offset(body.x - textResult.size.width / 2f, body.y - textResult.size.height / 2f)
                        )
                    }
                    else -> {
                        drawCircle(
                            color = body.color,
                            radius = body.radius,
                            center = Offset(body.x, body.y)
                        )
                    }
                }
            }
        }

        // Top Studio Action Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 40.dp, start = 16.dp, end = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onCloseStudio,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(SurfaceDark)
                    .testTag("close_studio_button")
            ) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
            }

            Surface(
                color = SurfaceDark,
                shape = RoundedCornerShape(20.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Escaped: ${physicsEngine.totalEscapedCount}",
                        color = NeonCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Bodies: ${physicsEngine.bodies.size}",
                        color = NeonPink,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            IconButton(
                onClick = { showControlsDrawer = !showControlsDrawer },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(if (showControlsDrawer) NeonCyan else SurfaceDark)
                    .testTag("toggle_controls_drawer_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = "Controls",
                    tint = if (showControlsDrawer) Color.Black else Color.White
                )
            }
        }

        // Floating Bottom Control Bar
        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(16.dp),
            color = SurfaceDark.copy(alpha = 0.95f),
            shape = RoundedCornerShape(24.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Play / Pause
                IconButton(
                    onClick = { isPlaying = !isPlaying },
                    modifier = Modifier.testTag("toggle_play_pause_button")
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = "Play/Pause",
                        tint = NeonCyan
                    )
                }

                // Reset Simulation
                IconButton(
                    onClick = {
                        physicsEngine.resetSimulation()
                    },
                    modifier = Modifier.testTag("reset_simulation_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reset",
                        tint = Color.White
                    )
                }

                // Save Project
                IconButton(
                    onClick = { showSaveTitleDialog = true },
                    modifier = Modifier.testTag("save_project_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Save,
                        contentDescription = "Save",
                        tint = NeonGreen
                    )
                }

                // Render Video
                Button(
                    onClick = onStartRender,
                    modifier = Modifier.testTag("trigger_render_mp4_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPink),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.Movie, contentDescription = "Render", tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Render MP4", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Animated Drawer Panel for Tuning Parameters
        AnimatedVisibility(
            visible = showControlsDrawer,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 80.dp)
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp)
                    .padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    // Drawer Tabs
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Tab(
                            selected = selectedDrawerTab == 0,
                            onClick = { selectedDrawerTab = 0 },
                            text = { Text("Objects", color = if (selectedDrawerTab == 0) NeonCyan else Color.White) }
                        )
                        Tab(
                            selected = selectedDrawerTab == 1,
                            onClick = { selectedDrawerTab = 1 },
                            text = { Text("Rings & Physics", color = if (selectedDrawerTab == 1) NeonCyan else Color.White) }
                        )
                        Tab(
                            selected = selectedDrawerTab == 2,
                            onClick = { selectedDrawerTab = 2 },
                            text = { Text("Visuals & Effects", color = if (selectedDrawerTab == 2) NeonCyan else Color.White) }
                        )
                    }

                    HorizontalDivider(color = Color.White.copy(alpha = 0.1f), modifier = Modifier.padding(vertical = 8.dp))

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        when (selectedDrawerTab) {
                            0 -> {
                                Text("Object Count: ${config.objectCount}", color = Color.White, fontSize = 13.sp)
                                Slider(
                                    value = config.objectCount.toFloat(),
                                    onValueChange = { onConfigChange(config.copy(objectCount = it.toInt())) },
                                    valueRange = 1f..100f,
                                    colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                                )

                                Text("Object Size: ${config.objectSize.toInt()} dp", color = Color.White, fontSize = 13.sp)
                                Slider(
                                    value = config.objectSize,
                                    onValueChange = { onConfigChange(config.copy(objectSize = it)) },
                                    valueRange = 8f..40f,
                                    colors = SliderDefaults.colors(thumbColor = NeonPink, activeTrackColor = NeonPink)
                                )

                                Text("Custom Shape Type", color = Color.White, fontSize = 13.sp)
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(ShapeType.values()) { shape ->
                                        FilterChip(
                                            selected = config.selectedShape == shape,
                                            onClick = { onConfigChange(config.copy(selectedShape = shape)) },
                                            label = { Text(shape.name, fontSize = 11.sp) }
                                        )
                                    }
                                }
                            }
                            1 -> {
                                Text("Ring Count: ${config.ringCount}", color = Color.White, fontSize = 13.sp)
                                Slider(
                                    value = config.ringCount.toFloat(),
                                    onValueChange = { onConfigChange(config.copy(ringCount = it.toInt())) },
                                    valueRange = 1f..5f,
                                    colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                                )

                                Text("Gap Opening Angle: ${config.gapAngleDegrees.toInt()}°", color = Color.White, fontSize = 13.sp)
                                Slider(
                                    value = config.gapAngleDegrees,
                                    onValueChange = { onConfigChange(config.copy(gapAngleDegrees = it)) },
                                    valueRange = 10f..120f,
                                    colors = SliderDefaults.colors(thumbColor = NeonPink, activeTrackColor = NeonPink)
                                )

                                Text("Rotation Speed", color = Color.White, fontSize = 13.sp)
                                Slider(
                                    value = config.rotationSpeed,
                                    onValueChange = { onConfigChange(config.copy(rotationSpeed = it)) },
                                    valueRange = 0.2f..4.0f,
                                    colors = SliderDefaults.colors(thumbColor = NeonPurple, activeTrackColor = NeonPurple)
                                )

                                Text("Bounce / Restitution: ${String.format("%.2f", config.bounce)}", color = Color.White, fontSize = 13.sp)
                                Slider(
                                    value = config.bounce,
                                    onValueChange = { onConfigChange(config.copy(bounce = it)) },
                                    valueRange = 0.2f..1.1f,
                                    colors = SliderDefaults.colors(thumbColor = NeonGreen, activeTrackColor = NeonGreen)
                                )

                                Text("Gravity Y Acceleration: ${config.gravityY.toInt()}", color = Color.White, fontSize = 13.sp)
                                Slider(
                                    value = config.gravityY,
                                    onValueChange = { onConfigChange(config.copy(gravityY = it)) },
                                    valueRange = 0f..2500f,
                                    colors = SliderDefaults.colors(thumbColor = Color(0xFFFFB800), activeTrackColor = Color(0xFFFFB800))
                                )
                            }
                            2 -> {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Trail Effects", color = Color.White)
                                    Switch(
                                        checked = config.trailEffect,
                                        onCheckedChange = { onConfigChange(config.copy(trailEffect = it)) }
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Particle Burst Effects", color = Color.White)
                                    Switch(
                                        checked = config.particleEffects,
                                        onCheckedChange = { onConfigChange(config.copy(particleEffects = it)) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Save Project Dialog
        if (showSaveTitleDialog) {
            AlertDialog(
                onDismissRequest = { showSaveTitleDialog = false },
                title = { Text("Save Project", color = Color.White) },
                text = {
                    OutlinedTextField(
                        value = projectTitleInput,
                        onValueChange = { projectTitleInput = it },
                        label = { Text("Project Name") },
                        singleLine = true
                    )
                },
                confirmButton = {
                    Button(onClick = {
                        onSaveProject(projectTitleInput)
                        showSaveTitleDialog = false
                    }) {
                        Text("Save")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showSaveTitleDialog = false }) {
                        Text("Cancel")
                    }
                },
                containerColor = SurfaceDark
            )
        }

        // Simulation Complete Dialog
        if (showCompleteDialog) {
            AlertDialog(
                onDismissRequest = onDismissCompleteDialog,
                title = {
                    Text(
                        text = "Simulation Complete! 🎉",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column {
                        Text(
                            text = "Your physics simulation video was successfully rendered into a high-smoothness MP4 file.",
                            color = Color.White.copy(alpha = 0.8f)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        if (exportedFile != null) {
                            Text(
                                text = "File: ${exportedFile.name}",
                                color = NeonCyan,
                                fontSize = 12.sp
                            )
                        }
                    }
                },
                confirmButton = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (exportedFile != null) {
                                    val uri = FileProvider.getUriForFile(
                                        context,
                                        "${context.packageName}.fileprovider",
                                        exportedFile
                                    )
                                    val intent = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(uri, "video/mp4")
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(intent)
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Preview", tint = Color.Black)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Preview Video", color = Color.Black)
                        }

                        Button(
                            onClick = {
                                if (exportedFile != null) {
                                    val uri = FileProvider.getUriForFile(
                                        context,
                                        "${context.packageName}.fileprovider",
                                        exportedFile
                                    )
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "video/mp4"
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "Share Video"))
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonPink)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Share", tint = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share Video", color = Color.White)
                        }

                        TextButton(
                            onClick = onDismissCompleteDialog,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Back to Studio", color = Color.White)
                        }
                    }
                },
                containerColor = SurfaceDark
            )
        }
    }
}
