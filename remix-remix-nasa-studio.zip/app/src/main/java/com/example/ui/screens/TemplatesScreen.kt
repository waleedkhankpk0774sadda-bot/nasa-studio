package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Category
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.physics.TemplateType
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.SurfaceDark

data class TemplateItem(
    val type: TemplateType,
    val title: String,
    val subtitle: String,
    val description: String,
    val icon: ImageVector,
    val accentColor: Color,
    val tag: String
)

@Composable
fun TemplatesScreen(
    onSelectTemplate: (TemplateType) -> Unit
) {
    val templates = listOf(
        TemplateItem(
            type = TemplateType.ROTATING_RINGS_BALLS,
            title = "Template 1: Rotating Rings & Balls",
            subtitle = "Concentric circles with gap openings",
            description = "Multiple rings rotating in opposite directions with gap escapes and realistic momentum collisions.",
            icon = Icons.Default.Science,
            accentColor = NeonCyan,
            tag = "template_1_card"
        ),
        TemplateItem(
            type = TemplateType.EMOJI_FLAG_CIRCLES,
            title = "Template 2: Emoji & Flag Circles",
            subtitle = "Custom emoji and country flag objects",
            description = "Select country flags, space rockets, or custom emojis bouncing inside broken rotating containment shapes.",
            icon = Icons.Default.Stars,
            accentColor = NeonPink,
            tag = "template_2_card"
        ),
        TemplateItem(
            type = TemplateType.TEXT_CHARACTERS,
            title = "Template 3: Physics Text Letters",
            subtitle = "Each letter is a physics body",
            description = "Enter any text phrase. Every letter is separated into individual bouncing physics letters.",
            icon = Icons.Default.TextFields,
            accentColor = NeonPurple,
            tag = "template_3_card"
        ),
        TemplateItem(
            type = TemplateType.IMAGE_OBJECTS,
            title = "Template 4: Image Objects Mode",
            subtitle = "Custom PNG / JPG image bodies",
            description = "Import or render PNG images as physical rigid bodies in the simulation canvas.",
            icon = Icons.Default.Image,
            accentColor = Color(0xFFFFB800),
            tag = "template_4_card"
        ),
        TemplateItem(
            type = TemplateType.CUSTOM_OBJECTS,
            title = "Template 5: Custom Shapes Sandbox",
            subtitle = "Circles, Squares, Triangles, Stars & Emojis",
            description = "Full custom mode allowing shape mixing, gravity tuning, trail effects, and gap angle customization.",
            icon = Icons.Default.Category,
            accentColor = Color(0xFF00FF66),
            tag = "template_5_card"
        )
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Hero Banner Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(NeonPurple, NeonCyan)
                        )
                    )
            ) {
                AsyncImage(
                    model = com.example.R.drawable.physics_banner_1786076364321,
                    contentDescription = "Physics Banner",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    alpha = 0.45f
                )

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.Bottom
                ) {
                    Surface(
                        color = NeonPink,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "PHYSICS SIMULATION STUDIO",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Select a Studio Template",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "Customize physics, audio beats, and render smooth MP4 videos.",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 13.sp
                    )
                }
            }
        }

        items(templates) { item ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onSelectTemplate(item.type) }
                    .testTag(item.tag),
                colors = CardDefaults.cardColors(
                    containerColor = SurfaceDark
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(item.accentColor.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.title,
                            tint = item.accentColor,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.title,
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = item.subtitle,
                            color = item.accentColor,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = item.description,
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 12.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = { onSelectTemplate(item.type) },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(item.accentColor)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Launch",
                            tint = Color.Black
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}
