package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SpaceBlack = Color(0xFF090D16)
val CosmicNavy = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val GlassSurface = Color(0x331E293B)

val NeonCyan = Color(0xFF00F0FF)
val NeonPink = Color(0xFFFF007A)
val NeonPurple = Color(0xFF7928CA)
val NeonYellow = Color(0xFFFFB800)
val NeonGreen = Color(0xFF00FF66)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
