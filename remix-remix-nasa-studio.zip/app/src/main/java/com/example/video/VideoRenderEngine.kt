package com.example.video

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Environment
import android.util.Log
import com.example.physics.PhysicsBody
import com.example.physics.PhysicsConfig
import com.example.physics.PhysicsEngine
import com.example.physics.RingConstraint
import com.example.physics.ShapeType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class VideoResolution(val width: Int, val height: Int, val label: String) {
    RES_720P(720, 1280, "720p (HD - 720x1280)"),
    RES_1080P(1080, 1920, "1080p (Full HD - 1080x1920)"),
    RES_1440P(1440, 2560, "1440p (2K - 1440x2560)"),
    RES_4K(2160, 3840, "4K Ultra HD (2160x3840)")
}

data class RenderSettings(
    val resolution: VideoResolution = VideoResolution.RES_1080P,
    val fps: Int = 60,
    val bitrate: Int = 12_000_000, // 12 Mbps
    val durationSeconds: Int = 15,
    val mimeType: String = MediaFormat.MIMETYPE_VIDEO_AVC // H.264
)

data class RenderProgress(
    val currentFrame: Int,
    val totalFrames: Int,
    val progressFraction: Float,
    val isComplete: Boolean = false,
    val outputFile: File? = null,
    val errorMessage: String? = null
)

class VideoRenderEngine(private val context: Context) {

    suspend fun renderSimulationToMp4(
        physicsConfig: PhysicsConfig,
        renderSettings: RenderSettings,
        onProgress: (RenderProgress) -> Unit
    ): File? = withContext(Dispatchers.IO) {
        var mediaCodec: MediaCodec? = null
        var mediaMuxer: MediaMuxer? = null
        var outputFile: File? = null

        try {
            val width = renderSettings.resolution.width
            val height = renderSettings.resolution.height
            val fps = renderSettings.fps
            val totalDurationSec = renderSettings.durationSeconds
            val totalFrames = fps * totalDurationSec
            val dt = 1.0f / fps.toFloat()

            // Prepare output file
            val outputDir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir
            outputFile = File(outputDir, "NASA_Studio_${System.currentTimeMillis()}.mp4")

            // Configure MediaFormat
            val format = MediaFormat.createVideoFormat(renderSettings.mimeType, width, height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, renderSettings.bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }

            mediaCodec = MediaCodec.createEncoderByType(renderSettings.mimeType)
            mediaCodec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val inputSurface = mediaCodec.createInputSurface()
            mediaCodec.start()

            mediaMuxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var trackIndex = -1
            var muxerStarted = false

            // Create Physics Engine for offline deterministic stepping
            val offlineEngine = PhysicsEngine(physicsConfig)
            offlineEngine.updateCanvasCenter(width.toFloat(), height.toFloat())

            // Offscreen Bitmap & Canvas for drawing
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)

            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeCap = Paint.Cap.ROUND
            }
            val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
            }
            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 36f
                textAlign = Paint.Align.CENTER
            }

            val bufferInfo = MediaCodec.BufferInfo()
            val frameIntervalUs = 1_000_000L / fps

            val ringRectF = android.graphics.RectF()

            for (frame in 0 until totalFrames) {
                // Step physics offline
                offlineEngine.step(dt)

                // Render current frame to Canvas
                drawFrame(
                    canvas = canvas,
                    width = width,
                    height = height,
                    engine = offlineEngine,
                    config = physicsConfig,
                    paint = paint,
                    ringPaint = ringPaint,
                    fillPaint = fillPaint,
                    textPaint = textPaint,
                    ringRectF = ringRectF
                )

                // Lock Surface Canvas and draw bitmap safely
                val surfaceCanvas = try {
                    inputSurface.lockCanvas(null)
                } catch (e: Exception) {
                    Log.e("VideoRenderEngine", "lockCanvas error", e)
                    null
                }

                if (surfaceCanvas != null) {
                    try {
                        surfaceCanvas.drawBitmap(bitmap, 0f, 0f, null)
                    } finally {
                        inputSurface.unlockCanvasAndPost(surfaceCanvas)
                    }
                }

                // Drain Encoder Buffers
                var encoderOutputAvailable = true
                while (encoderOutputAvailable) {
                    val outputBufferIndex = mediaCodec.dequeueOutputBuffer(bufferInfo, 0)
                    if (outputBufferIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        encoderOutputAvailable = false
                    } else if (outputBufferIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        if (!muxerStarted) {
                            val newFormat = mediaCodec.outputFormat
                            trackIndex = mediaMuxer.addTrack(newFormat)
                            mediaMuxer.start()
                            muxerStarted = true
                        }
                    } else if (outputBufferIndex >= 0) {
                        val encodedData = mediaCodec.getOutputBuffer(outputBufferIndex)
                        if (encodedData != null && muxerStarted) {
                            if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                                bufferInfo.size = 0
                            }
                            if (bufferInfo.size != 0) {
                                bufferInfo.presentationTimeUs = frame * frameIntervalUs
                                mediaMuxer.writeSampleData(trackIndex, encodedData, bufferInfo)
                            }
                        }
                        mediaCodec.releaseOutputBuffer(outputBufferIndex, false)
                    }
                }

                // Notify progress
                val fraction = (frame + 1).toFloat() / totalFrames.toFloat()
                onProgress(
                    RenderProgress(
                        currentFrame = frame + 1,
                        totalFrames = totalFrames,
                        progressFraction = fraction
                    )
                )
            }

            // Signal End of Stream
            mediaCodec.signalEndOfInputStream()

            // Drain remaining frames
            var done = false
            while (!done) {
                val outputBufferIndex = mediaCodec.dequeueOutputBuffer(bufferInfo, 10_000)
                if (outputBufferIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    done = true
                } else if (outputBufferIndex >= 0) {
                    val encodedData = mediaCodec.getOutputBuffer(outputBufferIndex)
                    if (encodedData != null && muxerStarted && bufferInfo.size != 0) {
                        bufferInfo.presentationTimeUs = totalFrames * frameIntervalUs
                        mediaMuxer.writeSampleData(trackIndex, encodedData, bufferInfo)
                    }
                    mediaCodec.releaseOutputBuffer(outputBufferIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        done = true
                    }
                }
            }

            bitmap.recycle()

            onProgress(
                RenderProgress(
                    currentFrame = totalFrames,
                    totalFrames = totalFrames,
                    progressFraction = 1.0f,
                    isComplete = true,
                    outputFile = outputFile
                )
            )

            outputFile
        } catch (e: Exception) {
            Log.e("VideoRenderEngine", "Render error", e)
            onProgress(
                RenderProgress(
                    currentFrame = 0,
                    totalFrames = 100,
                    progressFraction = 0f,
                    isComplete = false,
                    errorMessage = e.message ?: "Unknown encoding error"
                )
            )
            null
        } finally {
            try {
                mediaCodec?.stop()
                mediaCodec?.release()
                mediaMuxer?.stop()
                mediaMuxer?.release()
            } catch (e: Exception) {
                Log.e("VideoRenderEngine", "Error releasing codec", e)
            }
        }
    }

    private fun drawFrame(
        canvas: Canvas,
        width: Int,
        height: Int,
        engine: PhysicsEngine,
        config: PhysicsConfig,
        paint: Paint,
        ringPaint: Paint,
        fillPaint: Paint,
        textPaint: Paint,
        ringRectF: android.graphics.RectF
    ) {
        // Draw Dark Canvas Background
        canvas.drawColor(android.graphics.Color.parseColor("#0A0E1A"))

        // Draw Cosmic Grid Lines
        paint.color = android.graphics.Color.parseColor("#152035")
        paint.strokeWidth = 2f
        val step = 80
        for (x in 0 until width step step) {
            canvas.drawLine(x.toFloat(), 0f, x.toFloat(), height.toFloat(), paint)
        }
        for (y in 0 until height step step) {
            canvas.drawLine(0f, y.toFloat(), width.toFloat(), y.toFloat(), paint)
        }

        // Draw Rings
        for (ring in engine.rings) {
            ringPaint.color = ring.color.toArgbInt()
            ringPaint.strokeWidth = ring.thickness

            val radius = ring.radius
            val gapStartDeg = Math.toDegrees((ring.gapAngleCenter + ring.gapWidthAngle / 2f).toDouble()).toFloat()
            val sweepDeg = 360f - Math.toDegrees(ring.gapWidthAngle.toDouble()).toFloat()

            ringRectF.set(
                engine.centerX - radius,
                engine.centerY - radius,
                engine.centerX + radius,
                engine.centerY + radius
            )

            canvas.drawArc(ringRectF, gapStartDeg, sweepDeg, false, ringPaint)
        }

        // Draw Trail Effects
        if (config.trailEffect) {
            fillPaint.style = Paint.Style.FILL
            for (body in engine.bodies) {
                for (trail in body.trailHistory) {
                    fillPaint.color = body.color.toArgbInt()
                    fillPaint.alpha = (trail.alpha * 80).toInt().coerceIn(0, 255)
                    canvas.drawCircle(trail.x, trail.y, body.radius * 0.6f, fillPaint)
                }
            }
        }

        // Draw Physics Bodies
        for (body in engine.bodies) {
            fillPaint.color = body.color.toArgbInt()
            fillPaint.alpha = 255

            when (body.shapeType) {
                ShapeType.CIRCLE -> {
                    canvas.drawCircle(body.x, body.y, body.radius, fillPaint)
                }
                ShapeType.SQUARE -> {
                    val half = body.radius
                    canvas.drawRect(body.x - half, body.y - half, body.x + half, body.y + half, fillPaint)
                }
                ShapeType.EMOJI, ShapeType.TEXT_LETTER -> {
                    textPaint.color = android.graphics.Color.WHITE
                    textPaint.textSize = body.radius * 1.6f
                    canvas.drawText(body.label.ifEmpty { "★" }, body.x, body.y + body.radius * 0.5f, textPaint)
                }
                else -> {
                    canvas.drawCircle(body.x, body.y, body.radius, fillPaint)
                }
            }
        }
    }

    private fun androidx.compose.ui.graphics.Color.toArgbInt(): Int {
        return android.graphics.Color.argb(
            (this.alpha * 255).toInt(),
            (this.red * 255).toInt(),
            (this.green * 255).toInt(),
            (this.blue * 255).toInt()
        )
    }
}
